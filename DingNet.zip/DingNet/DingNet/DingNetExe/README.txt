The simulator is build for Java 9 and requires the following libraries:
-jxmapviewer 2.2.4
-jfreechart 1.5.0

To run the simulation, run the main method of the class MapView. To enable or disable the adaptation
approach on all motes (D1), set adaptation to true or false respectivly.
All graphs and maps are generated automatically. It also outputs the total amount of packets sent 
and the amount lost per mote. And the total amount of power used by mote 0 (D1).