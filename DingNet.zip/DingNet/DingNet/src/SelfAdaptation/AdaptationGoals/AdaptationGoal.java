package SelfAdaptation.AdaptationGoals;

/**
 * An abstract class representing an adaptation goal.
 */
public abstract class AdaptationGoal {

}
